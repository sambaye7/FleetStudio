package com.fleet.studio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@EnableAutoConfiguration
@SpringBootApplication
public class FleetstudioApplication {

	public static void main(String[] args) {
		SpringApplication.run(FleetstudioApplication.class, args);
	}

}
