package com.fleet.studio.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fleet.studio.model.HotelDetails;
import com.fleet.studio.services.HotelService;
import com.fleet.studio.utility.Response;

@RestController
@RequestMapping(value="/hotelManagement")
public class HotelManagement {
	
	
	@Autowired
	private HotelService hotelService;
	
	
	@PostMapping("/register")
	public Response<String> hotelRegistration(@RequestBody HotelDetails hotelDetails){
		return hotelService.registerHotels(hotelDetails);
		
	}
	
	@GetMapping("/objectmove")
	public Response<String> objectMovement(@RequestParam Integer hotelId, @RequestParam Integer floorId ){
		
		return hotelService.objectInside(hotelId, floorId);
	}
	
	@GetMapping("/objectoutside")
	public Response<String> objectOutSide(@RequestParam Integer hotelId, @RequestParam Integer floorId ){
		
		return hotelService.objectOutSide(hotelId, floorId);
	}
	
	@GetMapping("/hoteldetails")
	public Response<HotelDetails> getHotelDetails(@RequestParam Integer hotelId){
		
		return hotelService.getHotelData(hotelId);
	}

}
