package com.fleet.studio.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.fleet.studio.model.ConsumptionDetails;

@Repository
public interface ConsumptionRepo  extends JpaRepository<ConsumptionDetails, Integer>{

	public ConsumptionDetails findByFloorId(Integer floorId);
}
