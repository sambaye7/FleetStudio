package com.fleet.studio.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="floor_details")
public class FloorDetails {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="floor_id")
	private Integer floorId;
	
	@Column(name="hotel_id")
	private Integer hotelId;
	
	@Column(name="place_floor")
	private Integer placeOfFloor;

	@Column(name="main_corridors")
	private Integer mainCorridors; 
	
	@Column(name="sub_corridors")
	private Integer subCorridors; 

	@Column(name="main_lights")
	private Integer mainLightsCount;
	
	@Column(name="main_ac")
	private  Integer mainAcCount;
	
	@Column(name="sub_lights")
	private Integer subLightsCount;
	
	@Column(name="sub_ac")
	private  Integer subAcCount;
	
	@Column(name="light_status")
	private String lightStatus;
	
	@Column(name="ac_status")
	private String acStatus;
	
	@OneToOne
	@JoinColumn(name = "floor_id", referencedColumnName = "floor_id", insertable = false, updatable = false)
	private ConsumptionDetails consumptionDetails;

	public Integer getFloorId() {
		return floorId;
	}

	public void setFloorId(Integer floorId) {
		this.floorId = floorId;
	}
	
	

	public Integer getHotelId() {
		return hotelId;
	}

	public void setHotelId(Integer hotelId) {
		this.hotelId = hotelId;
	}

	public Integer getPlaceOfFloor() {
		return placeOfFloor;
	}

	public void setPlaceOfFloor(Integer placeOfFloor) {
		this.placeOfFloor = placeOfFloor;
	}

	public Integer getMainCorridors() {
		return mainCorridors;
	}

	public void setMainCorridors(Integer mainCorridors) {
		this.mainCorridors = mainCorridors;
	}

	public Integer getSubCorridors() {
		return subCorridors;
	}

	public void setSubCorridors(Integer subCorridors) {
		this.subCorridors = subCorridors;
	}

	public Integer getMainLightsCount() {
		return mainLightsCount;
	}

	public void setMainLightsCount(Integer mainLightsCount) {
		this.mainLightsCount = mainLightsCount;
	}

	public Integer getMainAcCount() {
		return mainAcCount;
	}

	public void setMainAcCount(Integer mainAcCount) {
		this.mainAcCount = mainAcCount;
	}

	public Integer getSubLightsCount() {
		return subLightsCount;
	}

	public void setSubLightsCount(Integer subLightsCount) {
		this.subLightsCount = subLightsCount;
	}

	public Integer getSubAcCount() {
		return subAcCount;
	}

	public void setSubAcCount(Integer subAcCount) {
		this.subAcCount = subAcCount;
	}
	

	public String getLightStatus() {
		return lightStatus;
	}

	public void setLightStatus(String lightStatus) {
		this.lightStatus = lightStatus;
	}

	public String getAcStatus() {
		return acStatus;
	}

	public void setAcStatus(String acStatus) {
		this.acStatus = acStatus;
	}

	public ConsumptionDetails getConsumptionDetails() {
		return consumptionDetails;
	}

	public void setConsumptionDetails(ConsumptionDetails consumptionDetails) {
		this.consumptionDetails = consumptionDetails;
	}
	
	


}
