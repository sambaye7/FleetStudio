package com.fleet.studio.model;

public class ObjectMovements {
	
	private Integer hotelId;
	
	private Integer floorId;
	
	private String corriderType;
	
	private Integer corridor;

	public Integer getHotelId() {
		return hotelId;
	}

	public void setHotelId(Integer hotelId) {
		this.hotelId = hotelId;
	}

	public Integer getFloorId() {
		return floorId;
	}

	public void setFloorId(Integer floorId) {
		this.floorId = floorId;
	}

	public String getCorriderType() {
		return corriderType;
	}

	public void setCorriderType(String corriderType) {
		this.corriderType = corriderType;
	}

	public Integer getCorridor() {
		return corridor;
	}

	public void setCorridor(Integer corridor) {
		this.corridor = corridor;
	}
	
	
	

}
