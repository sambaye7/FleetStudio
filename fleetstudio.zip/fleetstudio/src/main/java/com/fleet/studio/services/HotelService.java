package com.fleet.studio.services;

import com.fleet.studio.model.HotelDetails;
import com.fleet.studio.utility.Response;

public interface HotelService {

	public Response<String> registerHotels(HotelDetails hotelDetails);

	public Response<String> objectInside(Integer hotelId, Integer floorId);

	public Response<String> objectOutSide(Integer hotelId, Integer floorId);

	public Response<HotelDetails> getHotelData(Integer hotelId);

}
