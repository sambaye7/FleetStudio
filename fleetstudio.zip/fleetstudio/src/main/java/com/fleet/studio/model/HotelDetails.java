package com.fleet.studio.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="hotel_details")
public class HotelDetails {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="hotel_id")
	private Integer hotelId;
	
	@Column(name="hotel_name")
	private String hotelName;
	
	@Column(name="no_of_floors")
	private Integer noOfFloors;
	
	@OneToMany
	@JoinColumn(name = "hotel_id", referencedColumnName = "hotel_id", insertable = false, updatable = false)
	private  List<FloorDetails> floorDetails;

	public Integer getHotelId() {
		return hotelId;
	}

	public void setHotelId(Integer hotelId) {
		this.hotelId = hotelId;
	}

	public String getHotelName() {
		return hotelName;
	}

	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}

	public Integer getNoOfFloors() {
		return noOfFloors;
	}

	public void setNoOfFloors(Integer noOfFloors) {
		this.noOfFloors = noOfFloors;
	}

	public List<FloorDetails> getFloorDetails() {
		return floorDetails;
	}

	public void setFloorDetails(List<FloorDetails> floorDetails) {
		this.floorDetails = floorDetails;
	}
	
	
	
	
	

}
