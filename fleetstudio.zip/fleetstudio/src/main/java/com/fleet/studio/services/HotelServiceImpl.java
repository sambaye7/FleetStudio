package com.fleet.studio.services;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fleet.studio.model.ConsumptionDetails;
import com.fleet.studio.model.FloorDetails;
import com.fleet.studio.model.HotelDetails;
import com.fleet.studio.repo.ConsumptionRepo;
import com.fleet.studio.repo.FloorsRepo;
import com.fleet.studio.repo.HotelsRepo;
import com.fleet.studio.utility.Response;

@Service
public class HotelServiceImpl  implements HotelService{
	
	@Autowired
	private HotelsRepo hotelsRepo;
	
	@Autowired
	private FloorsRepo floorsRepo;
	
	@Autowired
	private ConsumptionRepo  consumptionRepo;

	@Override
	public Response<String> registerHotels(HotelDetails hotelDetails) {
		// TODO Auto-generated method stub
		Response<String> response = new Response<String>();
		if(hotelDetails != null) {
			HotelDetails hd = new HotelDetails();
			hd.setHotelName(hotelDetails.getHotelName());
			hd.setNoOfFloors(hotelDetails.getNoOfFloors());
			hd = hotelsRepo.save(hd);
			for(FloorDetails fd : hotelDetails.getFloorDetails()) {
				ConsumptionDetails cdetails = new ConsumptionDetails();
				fd.setHotelId(hd.getHotelId());
				fd.setLightStatus("OFF");
				fd.setAcStatus("OFF");
				FloorDetails fdetails = floorsRepo.save(fd);
				
				cdetails.setFloorId(fdetails.getFloorId());	
				cdetails.setAmountConsumption(0);
				consumptionRepo.save(cdetails);
				
			}
			response.setMessage("Hottel Details Registered....");
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
			
		}else {
			response.setMessage("Hottel Details Not Register....");
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
		}
		
		return response;
	}

	@Override
	public Response<String> objectInside(Integer hotelId, Integer floorId) {
		// TODO Auto-generated method stub
		
		FloorDetails fdetails = floorsRepo.findByHotelIdAndFloorId(hotelId, floorId);
		if(fdetails != null) {
		ConsumptionDetails cdetails = 	consumptionRepo.findByFloorId(fdetails.getFloorId());
		if(cdetails != null) {
			fdetails.setLightStatus("ON");
			fdetails.setAcStatus("ON");
			floorsRepo.save(fdetails);
			cdetails.setAmountConsumption(cdetails.getAmountConsumption()+5);
			consumptionRepo.save(cdetails);
		}
		}
		return null;
	}

	@Override
	public Response<String> objectOutSide(Integer hotelId, Integer floorId) {
		// TODO Auto-generated method stub
		Response<String> response = new Response<String>();
		FloorDetails fdetails = floorsRepo.findByHotelIdAndFloorId(hotelId, floorId);
		if(fdetails != null) {
		
			fdetails.setLightStatus("OFF");
			fdetails.setAcStatus("OFF");
			floorsRepo.save(fdetails);
			response.setMessage("Object Inside....");
			response.setStatus(HttpServletResponse.SC_OK);
		}else {
			response.setMessage("Hottel Details Not Found....");
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
		}
		return response;
	}

	@Override
	public Response<HotelDetails> getHotelData(Integer hotelId) {
		// TODO Auto-generated method stub
		Response<HotelDetails> response = new Response<HotelDetails>();
		if(hotelId != null) {
			HotelDetails hDetails = hotelsRepo.findByHotelId(hotelId);
			if(hDetails != null) {
				for(FloorDetails fd :   hDetails.getFloorDetails()) {
					ConsumptionDetails cdetails = consumptionRepo.findByFloorId(fd.getFloorId());
					fd.setConsumptionDetails(cdetails);
				}
				response.setData(hDetails);
				response.setMessage("Hottel Details....");
				response.setStatus(HttpServletResponse.SC_OK);
			}else {
				response.setMessage("Hottel Details Not Found....");
				response.setStatus(HttpServletResponse.SC_NOT_FOUND);
			}
		}else {
			response.setMessage("Hottel Details Not Found....");
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
		}
		return response;
	}

}
