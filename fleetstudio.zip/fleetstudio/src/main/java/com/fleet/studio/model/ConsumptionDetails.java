package com.fleet.studio.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="consumption_details")
public class ConsumptionDetails {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="consumption_id")
	private Integer consumptionId;
	
	@Column(name="floor_id")
	private Integer floorId;
	
	@Column(name="amount_consumption")
	private Integer amountConsumption;

	public Integer getConsumptionId() {
		return consumptionId;
	}

	public void setConsumptionId(Integer consumptionId) {
		this.consumptionId = consumptionId;
	}

	

	public Integer getFloorId() {
		return floorId;
	}

	public void setFloorId(Integer floorId) {
		this.floorId = floorId;
	}

	public Integer getAmountConsumption() {
		return amountConsumption;
	}

	public void setAmountConsumption(Integer amountConsumption) {
		this.amountConsumption = amountConsumption;
	}
	
	
	
	
	
	

}
