package com.fleet.studio.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.fleet.studio.model.FloorDetails;

@Repository
public interface FloorsRepo extends JpaRepository<FloorDetails, Integer>{
	
	public FloorDetails findByHotelIdAndFloorId(Integer hotelId, Integer floorId);

}
