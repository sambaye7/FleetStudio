package com.fleet.studio.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.fleet.studio.model.HotelDetails;

@Repository
public interface HotelsRepo extends JpaRepository<HotelDetails, Integer> {
	
	public HotelDetails findByHotelId(Integer hotelId);

}
